typedef struct telemento elemento;
typedef elemento * pilha;

//Recebe uma pilha e um caratere, empilha o caractere
// e devolve o endereco da nova pilha
elemento * empilhar(elemento * P, char c);

//comentario
pilha desempilhar(pilha P, char * resultado);

//comentario
int pilha_vazia(pilha P);